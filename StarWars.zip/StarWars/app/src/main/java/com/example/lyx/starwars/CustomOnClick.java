package com.example.lyx.starwars;

/**
 * Created by lyx on 3/20/18.
 */

public interface CustomOnClick {
    void onClickEvent(Personaje personaje, int position);
}
