package com.example.lyx.starwars;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lyx on 3/20/18.
 */

public class PersonajeRecyclerViewAdapter extends RecyclerView.Adapter <PersonajeRecyclerViewAdapter.ViewHolder> {

    public LayoutInflater inflater = null;
    private ArrayList<Personaje> personajes;
    private ArrayList<Personaje> personajesv;
    CustomOnClick customOnClick;

    public final class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView pName;

        public ViewHolder(View itemView) {
            super(itemView);

            pName = (TextView) itemView.findViewById(R.id.nameTextView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            customOnClick.onClickEvent(personajes.get(getLayoutPosition()), getLayoutPosition());
        }
    }

    public PersonajeRecyclerViewAdapter(Context context, ArrayList<Personaje> courses, CustomOnClick customOnClick) {

        if (context == null || courses == null ) {
            throw new IllegalArgumentException();
        }

        personajes=new ArrayList<Personaje>();
        personajes.addAll(courses);
        personajesv=new ArrayList<Personaje>();
        personajesv.addAll(courses);
        this.inflater = LayoutInflater.from(context);
        this.customOnClick = customOnClick;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View rowView = inflater.inflate(R.layout.list_item_personaje, parent, false);
        return new ViewHolder(rowView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.pName.setText(personajes.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return personajes.size();
    }

    public void addPersonaje(Personaje course) {

        if (course == null) {
            throw new IllegalArgumentException();
        }

        personajes.add(course);
        personajesv.add(course);

        // Importante: notificar que ha cambiado el dataset
        notifyDataSetChanged();
    }

    public void filtraPeli(int peli) {

        personajes.removeAll(personajesv);
        if (peli == 0) {
            personajes.addAll(personajesv);
        }

        for(Personaje p:personajesv){
            if(p.getFilms().contains(Integer.toString(peli)))
                personajes.add(p);
        }

        // Importante: notificar que ha cambiado el dataset
        notifyDataSetChanged();
    }

    public ArrayList<Personaje> getPersonajes() {
        return personajes;
    }

    public ArrayList<Personaje> getPersonajesv() {
        return personajesv;
    }
}