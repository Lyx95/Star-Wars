package com.example.lyx.starwars;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by lyx on 3/20/18.
 */

public class Personaje implements Parcelable{

    private String name;
    String height;
    String mass;
    String hair_color;
    String skin_color;
    String eye_color;
    String birth_year;
    String gender;
    String homeworld;
    ArrayList<String> films;
    String species;
    ArrayList<String> vehicles;
    ArrayList<String> starships;

    public Personaje() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getMass() {
        return mass;
    }

    public void setMass(String mass) {
        this.mass = mass;
    }

    public String getHair_color() {
        return hair_color;
    }

    public void setHair_color(String hair_color) {
        this.hair_color = hair_color;
    }

    public String getSkin_color() {
        return skin_color;
    }

    public void setSkin_color(String skin_color) {
        this.skin_color = skin_color;
    }

    public String getEye_color() {
        return eye_color;
    }

    public void setEye_color(String eye_color) {
        this.eye_color = eye_color;
    }

    public String getBirth_year() {
        return birth_year;
    }

    public void setBirth_year(String birth_year) {
        this.birth_year = birth_year;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHomeworld() {
        return homeworld;
    }

    public void setHomeworld(String homeworld) {
        this.homeworld = homeworld;
    }

    public ArrayList<String> getFilms() {
        return films;
    }

    public void setFilms(ArrayList<String> films) {
        this.films = films;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public ArrayList<String> getVehicles() {
        return vehicles;
    }

    public void setVehicles(ArrayList<String> vehicles) {
        this.vehicles = vehicles;
    }

    public ArrayList<String> getStarships() {
        return starships;
    }

    public void setStarships(ArrayList<String> starships) {
        this.starships = starships;
    }

    @Override
    public int describeContents() {
        return 0;
    }


    public Personaje(Parcel parcel) {

        readFromParcel(parcel);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(height);
        dest.writeString(mass);
        dest.writeString(hair_color);
        dest.writeString (skin_color);
        dest.writeString (eye_color);
        dest.writeString (birth_year);
        dest.writeString (gender);
        dest.writeString (homeworld);
        dest.writeStringList (films);
        dest.writeString (species);
        dest.writeStringList(vehicles);
        dest.writeStringList (starships);

    }

    public void readFromParcel(Parcel dest) {
        name=dest.readString();
        height=dest.readString();
        mass=dest.readString();
        hair_color=dest.readString();
        skin_color=dest.readString();
        eye_color=dest.readString();
        birth_year=dest.readString();
        gender=dest.readString();
        homeworld=dest.readString();
        films=new ArrayList<String>();
        dest.readStringList(films);
        species=dest.readString();
        vehicles=new ArrayList<String>();
        dest.readStringList(vehicles);
        starships=new ArrayList<String>();
        dest.readStringList(starships);

    }

    public static final Parcelable.Creator<Personaje> CREATOR =
            new Parcelable.Creator<Personaje>() {

                public Personaje createFromParcel(Parcel in) {
                    return new Personaje(in);
                }

                public Personaje[] newArray(int size) {
                    return new Personaje[size];
                }
            };
}
