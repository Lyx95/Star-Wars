package com.example.lyx.starwars;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by lyx on 3/20/18.
 */

public class PersonajeDetailsFragment extends Fragment {
    private static final String DESCRIPTION_ARG = "personaje";
    private Personaje personaje;

    public static PersonajeDetailsFragment newInstance(Personaje desc) {

        PersonajeDetailsFragment fragment = new PersonajeDetailsFragment();

        Bundle args = new Bundle();
        args.putParcelable(DESCRIPTION_ARG, desc);
        fragment.setArguments(args);

        return fragment;
    }

    public PersonajeDetailsFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView;
        rootView = inflater.inflate(R.layout.personaje_details_fragment, container, false);

        // Si estamos restaurando desde un estado previo no hacemos nada
        if (savedInstanceState != null) {
            return rootView;
        }

        Bundle args = getArguments();
        TextView tvName = (TextView) rootView.findViewById(R.id.tvName);
        TextView tvMass = (TextView) rootView.findViewById(R.id.tvMass);
        TextView tvHeigth = (TextView) rootView.findViewById(R.id.tvHeight);
        TextView tvHair = (TextView) rootView.findViewById(R.id.tvHair);
        TextView tvSkin = (TextView) rootView.findViewById(R.id.tvSkin);
        TextView tvEye = (TextView) rootView.findViewById(R.id.tvEyes);
        TextView tvBirth = (TextView) rootView.findViewById(R.id.tvBirth);
        TextView tvGender = (TextView) rootView.findViewById(R.id.tvGender);
        TextView tvHomeword = (TextView) rootView.findViewById(R.id.tvHomeword);
        TextView tvFilms = (TextView) rootView.findViewById(R.id.tvFilms);
        TextView tvSpecies = (TextView) rootView.findViewById(R.id.tvSpecies);
        TextView tvVehicles = (TextView) rootView.findViewById(R.id.tvVehicles);
        TextView tvStarships = (TextView) rootView.findViewById(R.id.tvStarships);

        /*

    int height;
    int mass;
    String hair_color;
    String skin_color;
    String eye_color;
    String birth_year;
    String gender;
    String homeworld;
    ArrayList<String> films;
    String species;
    ArrayList<String> vehicles;
    ArrayList<String> starships;
         */

        if (args != null) {
            personaje = args.getParcelable(DESCRIPTION_ARG);
            tvName.setText("Nombre: "+ personaje.getName());
            tvHeigth.setText("Heigth: "+personaje.getHeight());
            tvMass.setText("Mass: "+personaje.getMass());
            tvHair.setText("Hair: "+personaje.getHair_color());
            tvSkin.setText("Skin: "+personaje.getSkin_color());
            tvEye.setText("Eye: "+personaje.getEye_color());
            tvBirth.setText("Birth: "+personaje.getBirth_year());
            tvGender.setText("Gender: "+personaje.getGender());
            tvHomeword.setText("Homeworld: "+personaje.getHomeworld());
            tvFilms.setText("Film: "+personaje.getFilms());
            tvSpecies.setText("Specie: "+personaje.getSpecies());
            tvVehicles.setText("Vehicles: "+personaje.getVehicles());
            tvStarships.setText("Starships: "+personaje.getStarships());
        }

        return rootView;
    }
}
