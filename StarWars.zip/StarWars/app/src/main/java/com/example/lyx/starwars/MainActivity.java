package com.example.lyx.starwars;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ProgressBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, CustomOnClick,PersonajeListFragment.Callbacks {

    public static int posicion = 0;
    private PersonajeRecyclerViewAdapter adapter;
    String url="https://swapi.co/api/people/?page=1";
    private ArrayList<Personaje> personajes;
    private ProgressBar progressBar;
    private String next;
    private int filterFilm=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null)
            setSupportActionBar(toolbar);
        setSupportActionBar(toolbar);

        progressBar = (ProgressBar) findViewById(R.id.progress_bar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connMgr != null;


        // Existe el contenedor del fragmento?
        if (findViewById(R.id.course_list_frag) != null) {
            if (savedInstanceState != null) {
                personajes= savedInstanceState.getParcelableArrayList("personajes");
                filterFilm= savedInstanceState.getInt("peli");
                adapter= new PersonajeRecyclerViewAdapter(this,personajes,this);
            }
            else{
                if(isOnline()){
                    adapter= new PersonajeRecyclerViewAdapter(this,new ArrayList<Personaje>(),this);
                    progressBar.setVisibility(View.VISIBLE);
                    DownloadJsonTask a = new DownloadJsonTask();
                    a.execute(url);
            }
            }

            // Crear el fragmento pasándole el parámetro
            PersonajeListFragment fragment = PersonajeListFragment.newInstance();

            fragment.setAdapter(adapter);

            // Añadir el fragmento al contenedor 'fragment_container'
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.course_list_frag, fragment).commit();

            adapter.filtraPeli(filterFilm);
        }

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        personajes=adapter.getPersonajesv();
        savedInstanceState.putParcelableArrayList("personajes", personajes);
        savedInstanceState.putInt("peli", filterFilm);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_personajes) {
            // Handle the camera action
            adapter.filtraPeli(0);
            filterFilm=0;
        } else if (id == R.id.nav_peli1) {
            adapter.filtraPeli(4);
            filterFilm=4;

        } else if (id == R.id.nav_peli2) {
            adapter.filtraPeli(5);
            filterFilm=5;

        } else if (id == R.id.nav_peli3) {
            adapter.filtraPeli(6);
            filterFilm=6;

        } else if (id == R.id.nav_peli4) {
            adapter.filtraPeli(1);
            filterFilm=1;

        } else if (id == R.id.nav_peli5) {
            adapter.filtraPeli(2);
            filterFilm=2;

        } else if (id == R.id.nav_peli6) {
            adapter.filtraPeli(3);
            filterFilm=3;

        } else if (id == R.id.nav_peli7) {
            adapter.filtraPeli(7);
            filterFilm=7;

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



    @Override
    public void onClickEvent(Personaje personaje, int position) {

        Intent intent = new Intent(this, PersonajeDetailsActivity.class);
        intent.putExtra(PersonajeDetailsActivity.DESCRIPTION, personaje);
        startActivity(intent);
    }

    @Override
    public void onPersonajeSelected(Personaje personaje) {

        Intent intent = new Intent(this, PersonajeDetailsActivity.class);
        intent.putExtra(PersonajeDetailsActivity.DESCRIPTION, personaje.getName());
        startActivity(intent);
    }



    boolean isOnline() {
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
        //return true;
    }

    private InputStream openHttpInputStream(String myUrl)
            throws MalformedURLException, IOException, ProtocolException {
        InputStream is;
        URL url = new URL(myUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        // Aquí se hace realmente la petición
        conn.connect();

        is = conn.getInputStream();
        return is;
    }


    public void populateList(ArrayList<Personaje> personajes){
        for(Personaje p:personajes)
            adapter.addPersonaje(p);
    }

    private class DownloadJsonTask extends AsyncTask<String, Void, ArrayList<Personaje>> {

        private static final String NEXT_TAG = "next";
        private static final String RESULTS_TAG = "results";
        private static final String NAME_TAG = "name";
        private static final String HEIGT_TAG = "height";
        private static final String MASS_TAG = "mass";
        private static final String HAIR_TAG = "hair_color";
        private static final String SKIN_TAG = "skin_color";
        private static final String EYE_TAG = "eye_color";
        private static final String BIRTH_TAG = "birth_year";
        private static final String GENDER_TAG = "gender";
        private static final String HOMEWORLD_TAG = "homeworld";
        private static final String FILMS_TAG = "films";
        private static final String SPECIES_TAG = "species";
        private static final String VEHICLES_TAG = "vehicles";
        private static final String STARSHIPS_TAG = "starships";
        private static final String TITTLE_TAG = "tittle";
        private static final String EPISODES_TAG = "episode_id";

        private ArrayList<Personaje> parseJsonBusFile(String jsonBusInformation)
                throws JSONException, IOException {
            ArrayList<Personaje> result = new ArrayList<Personaje>();
            String json=jsonBusInformation;
            boolean continua=true;

                JSONObject root = new JSONObject(json);
                next = root.getString(NEXT_TAG);
                JSONArray personajesArray = root.getJSONArray(RESULTS_TAG);

                for (int i = 0; i < personajesArray.length(); i++) {
                    Personaje p = new Personaje();
                    JSONObject anArrival = personajesArray.getJSONObject(i);

                    p.setName(anArrival.getString(NAME_TAG));
                    p.setBirth_year(anArrival.getString(BIRTH_TAG));
                    p.setHeight(anArrival.getString(HEIGT_TAG));
                    p.setMass(anArrival.getString(MASS_TAG));
                    p.setHair_color(anArrival.getString(HAIR_TAG));
                    p.setSkin_color(anArrival.getString(SKIN_TAG));
                    p.setEye_color(anArrival.getString(EYE_TAG));
                    p.setGender(anArrival.getString(GENDER_TAG));
                    p.setHomeworld(anArrival.getString(HOMEWORLD_TAG));


                    ArrayList<String> films=new ArrayList<String>();
                    JSONArray filmsArray = anArrival.getJSONArray(FILMS_TAG);
                    for (int j = 0; j < filmsArray.length(); j++) {
                        String anFilm = String.valueOf(filmsArray.getString(j).charAt(filmsArray.getString(j).length() - 2));
                        films.add(anFilm);
                    }
                    p.setFilms(films);


                    ArrayList<String> sp=new ArrayList<String>();
                    JSONArray spArray = anArrival.getJSONArray(SPECIES_TAG);
                    String s;
                    if(spArray.length()>0)
                        s= spArray.getString(0);
                    else
                        s="";

                    p.setSpecies(s);

                    ArrayList<String> vehicles=new ArrayList<String>();
                    JSONArray vehiclesArray = anArrival.getJSONArray(VEHICLES_TAG);
                    for (int j = 0; j < vehiclesArray.length(); j++) {
                        String anVehicle = vehiclesArray.getString(j);
                        vehicles.add(anVehicle);
                    }

                    p.setVehicles(vehicles);


                    ArrayList<String> starships=new ArrayList<String>();
                    JSONArray starshipsArray = anArrival.getJSONArray(STARSHIPS_TAG);
                    for (int j = 0; j < starshipsArray.length(); j++) {
                        String anStarship = starshipsArray.getString(j);
                        starships.add(anStarship);
                    }
                    p.setStarships(starships);

                    result.add(p);
                }

            return result;
        }


        @Override
        protected ArrayList<Personaje> doInBackground(String... urls) {

            // urls vienen de la llamada a execute(): urls[0] es la url
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                // TODO: las cadenas deberían ser recursos
                return null;
            }
        }

        private ArrayList<Personaje> downloadUrl(String myUrl) throws IOException {
            InputStream is = null;

            try {
                is = openHttpInputStream(myUrl);
                return parseJsonBusFile(streamToString(is));
            } catch (JSONException e) {
                return null;
            } finally {
                // Asegurarse de que el InputStream se cierra
                if (is != null) {
                    is.close();
                }

            }
        }

        // Pasa un InputStream a un String
        public String streamToString(InputStream stream) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int bufferSize = 5000;
            byte[] buffer = new byte[bufferSize];
            int length = 0;
            do {
                length = stream.read(buffer);
                if (length != -1) {
                    baos.write(buffer, 0, length);
                }
            } while (length != -1);

            return baos.toString("UTF-8");
        }

        // Muestra el resultado en un text_view
        @Override
        protected void onPostExecute(ArrayList<Personaje> result) {
            populateList(result);
            personajes=result;

            if(next!="null"){
                progressBar.setVisibility(View.VISIBLE);
                DownloadJsonTask a = new DownloadJsonTask();
                a.execute(next);
            }
            else
                progressBar.setVisibility(View.INVISIBLE);

        }
    }


}
