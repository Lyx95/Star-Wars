package com.example.lyx.starwars;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by lyx on 3/20/18.
 */

public class PersonajeDetailsActivity extends AppCompatActivity {


    public static final String DESCRIPTION = "es.uniovi.imovil.user.courses.DESCRIPTION";

    Personaje personaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personaje_details_activity);

        // my_child_toolbar is defined in the layout file
        Toolbar myChildToolbar =
                (Toolbar) findViewById(R.id.toolbarDetails);
        setSupportActionBar(myChildToolbar);

        // Get a support ActionBar corresponding to this toolbar
        ActionBar ab = getSupportActionBar();

        // Enable the Up button
        if (ab != null) {
            ab.setDisplayHomeAsUpEnabled(true);
        }

        // Existe el contenedor del fragmento?
        if (findViewById(R.id.fragment_details) != null) {

            Intent intent = getIntent();
            personaje = intent.getParcelableExtra(DESCRIPTION);

            if(isOnline()){
                AsyncTask<String, Void, String> d=new DownloadDetails();
                d.execute();
            }

        }
    }




    boolean isOnline() {
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }

    private InputStream openHttpInputStream(String myUrl)
            throws MalformedURLException, IOException, ProtocolException {
        InputStream is;
        URL url = new URL(myUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        // Aquí se hace realmente la petición
        conn.connect();

        is = conn.getInputStream();
        return is;
    }


    private class DownloadDetails extends AsyncTask<String, Void, String> {

        private static final String NAME_TAG = "name";
        private static final String TITTLE_TAG = "tittle";
        private static final String EPISODES_TAG = "episode_id";

        @Override
        protected String doInBackground(String... urls) {

            // urls vienen de la llamada a execute(): urls[0] es la url
            try {
                if(!personaje.getSpecies().equals(""))
                    personaje.setSpecies(downloadUrl(personaje.getSpecies(),NAME_TAG));


                ArrayList<String> vehicles= personaje.getVehicles();
                for (int j = 0; j < vehicles.size(); j++) {
                    String anVehicle = downloadUrl(vehicles.get(j),NAME_TAG);
                    vehicles.set(j,anVehicle);
                }
                personaje.setVehicles(vehicles);


                ArrayList<String> starship= personaje.getStarships();
                for (int j = 0; j < starship.size(); j++) {
                    String anVehicle = downloadUrl(starship.get(j),NAME_TAG);
                    starship.set(j,anVehicle);
                }
                personaje.setStarships(starship);

                return "";
            } catch (IOException e) {
                // TODO: las cadenas deberían ser recursos
                return null;
            }
        }

        private String downloadUrl(String myUrl, String tag) throws IOException {
            InputStream is = null;

            try {
                is = openHttpInputStream(myUrl);
                return ParseItem(streamToString(is),tag);
            } catch (JSONException e) {
                return null;
            } finally {
                // Asegurarse de que el InputStream se cierra
                if (is != null) {
                    is.close();
                }

            }
        }


        private String parseJsonBusFile(String myUrl, String tag) throws IOException {
            InputStream is = null;

            try {
                is = openHttpInputStream(myUrl);
                return ParseItem(streamToString(is),tag);
            } catch (JSONException e) {
                return null;
            } finally {
                // Asegurarse de que el InputStream se cierra
                if (is != null) {
                    is.close();
                }

            }
        }


        private String ParseItem(String jsonBusInformation, String tag)
                throws JSONException {
            JSONObject root = new JSONObject(jsonBusInformation);
            return root.getString(tag);
        }

        // Pasa un InputStream a un String
        public String streamToString(InputStream stream) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int bufferSize = 5000;
            byte[] buffer = new byte[bufferSize];
            int length = 0;
            do {
                length = stream.read(buffer);
                if (length != -1) {
                    baos.write(buffer, 0, length);
                }
            } while (length != -1);

            return baos.toString("UTF-8");
        }

        // Muestra el resultado en un text_view
        @Override
        protected void onPostExecute(String result) {

            // Crear el fragmento pasándole el parámetro

            PersonajeDetailsFragment fragment =
                    PersonajeDetailsFragment.newInstance(personaje);

            // Añadir el fragmento al contenedor 'fragment_container'
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_details, fragment).commit();

        }
    }

}
