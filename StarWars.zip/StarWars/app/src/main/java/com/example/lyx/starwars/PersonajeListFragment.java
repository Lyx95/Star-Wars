package com.example.lyx.starwars;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.example.lyx.starwars.MainActivity.posicion;
import static java.security.AccessController.getContext;

/**
 * Created by lyx on 3/20/18.
 */

public class PersonajeListFragment extends Fragment implements
        AdapterView.OnItemClickListener,CustomOnClick {

    private static final String DESCRIPTION_ARG = "description";

    Personaje personaje;
    ArrayList<Personaje> personajes;
    private Callbacks mCallback;
    public RecyclerView recyclerView;
    public PersonajeRecyclerViewAdapter adapter;

    public void setAdapter(PersonajeRecyclerViewAdapter adapter) {
        this.adapter = adapter;
        this.personajes=adapter.getPersonajes();
    }

    public static PersonajeListFragment newInstance() {

        PersonajeListFragment fragment = new PersonajeListFragment();


        return fragment;
    }

    public PersonajeListFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView;
        rootView = inflater.inflate(R.layout.personaje_list_fragment,
                container, false);

        // Inicializar el layout
        // ...
        recyclerView= rootView.findViewById(R.id.recycler_view_personajes);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return rootView;
    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {
        personaje = (Personaje) parent.getItemAtPosition(position);

        Intent intent = new Intent(getContext(), PersonajeDetailsActivity.class);
        intent.putExtra(PersonajeDetailsActivity.DESCRIPTION, personaje);
        startActivity(intent);

        mCallback.onPersonajeSelected(personaje);
    }

    @Override
    public void onClickEvent(Personaje personaje, int position) {

    }

    public interface Callbacks {
        public void onPersonajeSelected(Personaje personaje);
    }


    @Override
    public void onAttach(Activity activity) {

        super.onAttach(activity);
        try {
            mCallback = (Callbacks) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() +
                    " must implement Callbacks");
        }
    }

}